package com.sbsoftwareltd.namazshikha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class SuraActivity extends AppCompatActivity {

    Button s1,s2,s3,s4,s5,s6,s7,s8,s9,s10;
    private AdView mAdView6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sura);



        //==========

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        AdView adView = new AdView(this);

        adView.setAdSize(AdSize.BANNER);

        adView.setAdUnitId("ca-app-pub-6331473249617603/7694863398");

        mAdView6=findViewById(R.id.mAdView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView6.loadAd(adRequest);

        //========







        s1=findViewById(R.id.s1);
        s1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূরা ফাতিহা ";

                BebronActivity.LOVE2=" সূরা ফাতিহা এর আরবি উচ্চারণ \n" +
                        "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ\n" +
                        " الرَّحْمَٰنِ الرَّحِيمِ\n" +
                        "مَالِكِ يَوْمِ الدِّينِ\n" +
                        "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ\n" +
                        "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ\n" +
                        "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ\n" +
                        " غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ\n" +
                        "\n"+
                        "\n" +
                        "\n"+
                        "সূরা ফাতিহা এর বাংলা উচ্চারণ \n" +
                        "\n" +
                        "\n" +
                        "আলহামদু  লিল্লাহি রব্বিল আ -লামি-ন।\n" +
                        "আররহমা-নির রাহি-ম।\n" +
                        "মা-লিকি ইয়াওমিদ্দি-ন।\n" +
                        "ইয়্যা-কা না’বুদু ওয়া ইয়্যা-কা নাসতাই’-ন\n" +
                        "ইহদিনাস সিরাতা’ল মুসতাকি’-ম\n" +
                        "সিরাতা’ল্লা যি-না আনআ’মতা আ’লাইহিম\n" +
                        "গা’ইরিল মাগ’দু’বি আ’লাইহিম ওয়ালা দ্দ-ল্লি-ন।\n" +
                        "\nসূরা ফাতিহার বাংলা অর্থ -\n\n" +
                        "যাবতীয় প্রশংসা আল্লাহ তা’আলার যিনি সকল সৃষ্টি জগতের পালনকর্তা।\n" +
                        "যিনি নিতান্ত মেহেরবান ও দয়ালু।\n" +
                        "বিচার দিনের একমাত্র অধিপতি।\n" +
                        "আমরা একমাত্র তোমারই ইবাদত করি এবং শুধুমাত্র তোমারই সাহায্য প্রার্থনা করি।\n" +
                        "আমাদের সরল পথ দেখাও।\n" +
                        "সে সমস্ত লোকের পথ, যাদেরকে তুমি নেয়ামত দান করেছ।\n" +
                        " তাদের পথ নয়, যাদের প্রতি তোমার গজব নাযিল হয়েছে এবং যারা পথভ্রষ্ট হয়েছে।";


                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });

        s2=findViewById(R.id.s2);
        s2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূরা ইখলাস";

                BebronActivity.LOVE2="সূরা ইখলাস এর আরবি\n" +
                        "قُلْ هُوَ ٱللَّهُ أَحَدٌ\n" +
                        "ٱللَّهُ ٱلصَّمَدُ\n" +
                        "لَمْ يَلِدْ وَلَمْ يُولَدْ\n" +
                        "وَلَمْ يَكُن لَّهُۥ كُفُوًا أَحَدٌۢ\n" +
                        "\n" +
                        "\n" +
                        "সূরা ইখলাস এর বাংলা উচ্চারণ\n" +
                        "\n" +
                        "কুল হুওয়াল্লা-হু আহাদ।\n" +
                        "আল্লা-হুসসামাদ।\n" +
                        "লাম ইয়ালিদ ওয়ালাম ইঊলাদ।\n" +
                        "ওয়া লাম ইয়াকুল্লাহূকুফুওয়ান আহাদ।\n" +
                        "\n" +
                        "সূরা ইখলাস এর বাংলা অর্থ -\n" +
                        "\n" +
                        "বলুন, তিনি আল্লাহ, এক,\n" +
                        "আল্লাহ অমুখাপেক্ষী,\n" +
                        "তিনি কাউকে জন্ম দেননি এবং কেউ তাকে জন্ম দেয়নি\n" +
                        "এবং তার সমতুল্য কেউ নেই।";


                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });

        s3=findViewById(R.id.s3);
        s3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূরা আন নাস ";

                BebronActivity.LOVE2="সূরা আন নাস আরবি \n" +
                        "قُلْ أَعُوذُ بِرَبِّ ٱلنَّاسِ\n" +
                        "مَلِكِ ٱلنَّاسِ\n" +
                        "إِلَٰهِ ٱلنَّاسِ\n" +
                        "مِن شَرِّ ٱلْوَسْوَاسِ ٱلْخَنَّاسِ\n" +
                        "ٱلَّذِى يُوَسْوِسُ فِى صُدُورِ ٱلنَّاسِ\n" +
                        "مِنَ ٱلْجِنَّةِ وَٱلنَّاسِ\n" +
                        "" +
                        "\n" +
                        "\n" +
                        "সূরা আন নাস বাংলা উচ্চারণ-\n" +
                        "\n" +
                        "কুল আ‘ঊযুবিরাব্বিন্না-ছ,\n" +
                        "মালিকিন্না-ছ,\n" +
                        "ইলা-হিন্না-ছ।\n" +
                        "মিন শাররিল ওয়াছ ওয়া-ছিল খান্না-ছ।\n" +
                        "আল্লাযী ইউওয়াছবিছুফী সুদূরিন্নাছ-।\n" +
                        "মিনাল জিন্নাতি ওয়ান্না-ছ।\n" +
                        "\n" +
                        "সূরা আন নাস এর বাংলা  অর্থ-\n" +
                        "\n" +
                        "বলুন, আমি আশ্রয় গ্রহণ করিতেছি মানুষের পালনকর্তার,\n" +
                        "মানুষের অধিপতির,\n" +
                        "মানুষের মা’বুদের\n" +
                        "তার অনিষ্ট থেকে, যে কুমন্ত্রণা দেয় ও আত্নগোপন করে,\n" +
                        "যে কুমন্ত্রণা দেয় মানুষের অন্তরে\n" +
                        "জ্বিনের মধ্য থেকে অথবা মানুষের মধ্য থেকে।\n";


                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });



        s4=findViewById(R.id.s4);
        s4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূরা ফালাক ";

                BebronActivity.LOVE2="সূরা ফালাকের  আরবী উচ্চারণ \n" +
                        "قُلْ أَعُوذُ بِرَبِّ ٱلْفَلَقِ\n" +
                        "مِن شَرِّ مَا خَلَقَ\n" +
                        "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ\n" +
                        "وَمِن شَرِّ ٱلنَّفَّٰثَٰتِ فِى ٱلْعُقَدِ\n" +
                        "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ\n" +
                        "" +
                        "\nসূরা ফালাক এর বাংলা উচ্চারণ-\n" +
                        "\n" +
                        "কুল আ‘ঊযুবিরাব্বিল ফালাক\n" +
                        "মিন শাররি মা-খালাক।\n" +
                        "ওয়া মিন শাররি গা-ছিকিন ইযা-ওয়াকাব।\n" +
                        "ওয়া মিন শাররিন নাফফা-ছা-তি ফিল ‘উকাদ।\n" +
                        "ওয়া মিন শাররি হা-ছিদিন ইযা-হাছাদ।\n" +
                        "" +
                        "\nসূরা ফালাক এর বাংলা অর্থ-\n" +
                        "\n" +
                        "১) বলুন, আমি আশ্রয় গ্রহণ করছি প্রভাতের পালনকর্তার,\n" +
                        "২) তিনি যা সৃষ্টি করেছেন, তার অনিষ্ট থেকে,\n" +
                        "৩) অন্ধকার রাত্রির অনিষ্ট থেকে, যখন তা সমাগত হয়,\n" +
                        "৪) গ্রন্থিতে ফুঁৎকার দিয়ে জাদুকারিনীদের অনিষ্ট থেকে\n" +
                        "৫) এবং হিংসুকের অনিষ্ট থেকে যখন সে হিংসা করে।";


                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });



        s5=findViewById(R.id.s5);
        s5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূরা ফীল";

                BebronActivity.LOVE2="সূরা ফীল এর আরবি\n" +
                        "أَلَمْ تَرَ كَيْفَ فَعَلَ رَبُّكَ بِأَصْحَٰبِ ٱلْفِيلِ\n" +
                        "أَلَمْ يَجْعَلْ كَيْدَهُمْ فِى تَضْلِيلٍ\n" +
                        "وَأَرْسَلَ عَلَيْهِمْ طَيْرًا أَبَابِيلَ\n" +
                        "تَرْمِيهِم بِحِجَارَةٍ مِّن سِجِّيلٍ\n" +
                        "فَجَعَلَهُمْ كَعَصْفٍ مَّأْكُولٍۭ\n" +
                        "\nসূরা ফীল বাংলা উচ্চারণ-\n" +
                        "\n" +
                        "আলাম তারা কাইফা ফা‘আলা রাব্বুকা বিআসহা-বিল ফীল।\n" +
                        "আলাম ইয়াজ‘আল কাইদাহুম ফী তাদলীল\n" +
                        "ওয়া আরছালা ‘আলাইহিম তাইরান আবা-বীল।\n" +
                        "তারমীহিম বিহিজা-রাতিম মিন ছিজ্জীল।\n" +
                        "ফাজা‘আলাহুম কা‘আসফিম মা’কূল।\n" +
                        "\n" +
                        "সূরা ফীল বাংলা অর্থ-\n" +
                        "\n" +
                        "আপনি কি দেখেননি আপনার পালনকর্তা হস্তীবাহিনীর সাথে কিরূপ ব্যবহার করেছেন?\n" +
                        "তিনি কি তাদের চক্রান্ত নস্যাৎ করে দেননি?\n" +
                        "তিনি তাদের উপর প্রেরণ করেছেন ঝাঁকে ঝাঁকে পাখী,\n" +
                        "যারা তাদের উপর পাথরের কংকর নিক্ষেপ করছিল।\n" +
                        "অতঃপর তিনি তাদেরকে ভক্ষিত তৃণসদৃশ করে দেন।";


                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });


        s6=findViewById(R.id.s6);
        s6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূরা কাফিরুন";

                BebronActivity.LOVE2="সূরা কাফিরুন এর আরবি \n" +
                        "قُلْ يَٰٓأَيُّهَا ٱلْكَٰفِرُونَ\n" +
                        "لَآ أَعْبُدُ مَا تَعْبُدُونَ\n" +
                        "وَلَآ أَنتُمْ عَٰبِدُونَ مَآ أَعْبُدُ\n" +
                        "وَلَآ أَنَا۠ عَابِدٌ مَّا عَبَدتُّمْ\n" +
                        "وَلَآ أَنتُمْ عَٰبِدُونَ مَآ أَعْبُدُ\n" +
                        "لَكُمْ دِينُكُمْ وَلِىَ دِينِ\n" +
                        "\nসূরা কাফিরুন বাংলা উচ্চারণ-\n" +
                        "\n" +
                        "কুল ইয়াআইয়ুহাল কা-ফিরূন।\n" +
                        "লাআ‘বুদুমা-তা‘বুদূন।\n" +
                        "ওয়ালাআনতুম ‘আ-বিদূনা মাআ‘বুদ।\n" +
                        "ওয়ালাআনা ‘আ-বিদুম মা-‘আবাত্তুম,\n" +
                        "ওয়ালাআনতুম ‘আ-বিদূনা মাআ‘বুদ।\n" +
                        "লাকুম দীনুকুম ওয়ালিয়া দীন।\n" +
                        "\n" +
                        "সূরা কাফিরুন এর বাংলা অর্থ-\n" +
                        "\n" +
                        "বলুন, হে কাফেরকূল, আমি এবাদত করিনা, তোমরা যার এবাদত কর। \n" +
                        "এবং তোমরাও এবাদতকারী নও, যার এবাদত আমি করি \n" +
                        "এবং আমি এবাদতকারী নই, যার এবাদত তোমরা কর। \n" +
                        "তোমরা এবাদতকারী নও, যার এবাদত আমি করি। \n" +
                        "তোমাদের কর্ম ও কর্মফল তোমাদের জন্যে \n" +
                        "এবং আমার কর্ম ও কর্মফল আমার জন্যে।\n";


                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });
        s7=findViewById(R.id.s7);
        s7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূরা আন নাসর";

                BebronActivity.LOVE2="সূরা আন নাসর এর আরবী \n" +
                        "إِذَا جَآءَ نَصْرُ ٱللَّهِ وَٱلْفَتْحُ\n" +
                        "وَرَأَيْتَ ٱلنَّاسَ يَدْخُلُونَ فِى دِينِ ٱللَّهِ أَفْوَاجًا\n" +
                        "فَسَبِّحْ بِحَمْدِ رَبِّكَ وَٱسْتَغْفِرْهُ إِنَّهُۥ كَانَ تَوَّابًۢا\n" +
                        "\nসূরা আন নাসর এর বাংলা উচ্চারণ-\n" +
                        "\n" +
                        "ইযা-জাআ নাসরুল্লা-হি ওয়াল ফাতহ।\n" +
                        "ওয়ারাআইতান্না-ছা ইয়াদখুলূনা ফী দীনিল্লা-হি আফওয়া-জা-।\n" +
                        "ফাছাব্বিহবিহামদি রাব্বিকা ওয়াছতাগফিরহু ইন্নাহূকা-না তাওওয়া-বা-।\n" +
                        "\nসূরা আন নাসর এর অর্থ-\n\n" +
                        "যখন আসবে আল্লাহর সাহায্য ও বিজয়\n" +
                        "এবং আপনি মানুষকে দলে দলে আল্লাহর দ্বীনে প্রবেশ করতে দেখবেন,\n" +
                        "তখন আপনি আপনার পালনকর্তার পবিত্রতা বর্ণনা করুন এবং তাঁর কাছে ক্ষমা প্রার্থনা করুন। নিশ্চয় তিনি ক্ষমাকারী।";


                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });
        s8=findViewById(R.id.s8);
        s8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূরা কাওসার";

                BebronActivity.LOVE2="সূরা কাওসার এর আরবি \n" +
                        "إِنَّآ أَعْطَيْنَٰكَ ٱلْكَوْثَرَ\n" +
                        "فَصَلِّ لِرَبِّكَ وَٱنْحَرْ\n" +
                        "إِنَّ شَانِئَكَ هُوَ ٱلْأَبْتَرُ\n" +
                        "\nসূরা কাওসার বাংলা উচ্চারণ-\n" +
                        "\n" +
                        "ইন্নাআ‘তাইনা-কাল কাওছার।\n" +
                        "ফাসালিল লিরাব্বিকা ওয়ানহার।\n" +
                        "ইন্না শা-নিআকা হুওয়াল আবতার।\n" +
                        "\nসূরা কাওসার অর্থ-\n\n" +
                        "নিশ্চয় আমি আপনাকে কাওসার দান করেছি। \n" +
                        "অতএব আপনার পালনকর্তার উদ্দেশ্যে নামায পড়ুন এবং কোরবানী করুন। \n" +
                        "যে আপনার শত্রু, সেই তো লেজকাটা, নির্বংশ।";


                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });
        s9=findViewById(R.id.s9);
        s9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূূূরা মাউন";

                BebronActivity.LOVE2="সূূূরা মাউন এর আরবি \n" +
                        "أَرَءَيْتَ ٱلَّذِى يُكَذِّبُ بِٱلدِّين\n" +
                        "فَذَٰلِكَ ٱلَّذِى يَدُعُّ ٱلْيَتِيمَ\n" +
                        "وَلَا يَحُضُّ عَلَىٰ طَعَامِ ٱلْمِسْكِينِ فَوَيْلٌ لِّلْمُصَلِّينَ\n" +
                        "ٱلَّذِينَ هُمْ عَن صَلَاتِهِمْ سَاهُونَ\n" +
                        "ٱلَّذِينَ هُمْ يُرَآءُونَ\n" +
                        "وَيَمْنَعُونَ ٱلْمَاعُون\n" +
                        "\nসূরা মাউন এর বাংলা উচ্চারণ-\n" +
                        "\n" +
                        "আরাআইতাল্লাযী ইউকাযযি বুবিদ্দীন।\n" +
                        "ফাযা-লিকাল্লাযী ইয়াদু‘‘উল ইয়াতীম।\n" +
                        "ওয়ালা-ইয়াহুদ্দু‘আলা-তা‘আ-মিল মিছকীন। ফাওয়াইঁলুলিলল মুসাল্লীন।\n" +
                        "আল্লাযীনাহুম ‘আন সালা-তিহিমি\n" +
                        "ছা-হূন। আল্লাযীনা হুম ইউরাঊনা।\n" +
                        "ওয়া ইয়ামনা‘ঊনাল মা-‘ঊন।\n" +
                        "\nসূরা মাউন এর  বাংলা অর্থ -\n\n" +
                        "আপনি কি দেখেছেন তাকে, যে বিচারদিবসকে মিথ্যা বলে?\n" +
                        "সে সেই ব্যক্তি, যে এতীমকে গলা ধাক্কা দেয় \n" +
                        "এবং মিসকীনকে অন্ন দিতে উৎসাহিত করে না।অতএব দুর্ভোগ সেসব নামাযীর,\n" +
                        "যারা তাদের নামায সম্বন্ধে বে-খবর\n" +
                        " যারা তা লোক-দেখানোর জন্য করে \n" +
                        "এবং নিত্য ব্যবহার্য্য বস্তু অন্যকে দেয় না।\n";


                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });
        s10=findViewById(R.id.s10);
        s10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="সূরা কুরাইশ ";
                BebronActivity.LOVE2="সূরা কুরাইশ এর আরবী\n" +
                        "لِإِيلَٰفِ قُرَيْشٍ\n" +
                        "إِۦلَٰفِهِمْ رِحْلَةَ ٱلشِّتَآءِ وَٱلصَّيْفِ\n" +
                        "فَلْيَعْبُدُوا۟ رَبَّ هَٰذَا ٱلْبَيْتِ\n" +
                        "ٱلَّذِىٓ أَطْعَمَهُم مِّن جُوعٍ وَءَامَنَهُم مِّنْ خَوْفٍۭ\n" +
                        "\nসূরা কুরাইশ বাংলা উচ্চারণ-\n\n" +
                        "লিঈলা-ফি কুরাইশ।\n" +
                        "ঈলা-ফিহিম রিহলাতাশশিতাই ওয়াসসাঈফ।\n" +
                        "ফালইয়া‘বুদূরাব্বা হা-যাল বাঈত।\n" +
                        "আল্লাযীআতা‘আমাহুম মিন জূ‘ইওঁ ওয়া আ-মানাহুম মিন খাওফ।\n" +
                        "\nসূরা কুরাইশ এর বাংলা অর্থ-\n\n" +
                        "কোরাইশের আসক্তির কারণে, \n" +
                        "আসক্তির কারণে তাদের শীত ও গ্রীষ্মকালীন সফরের। \n" +
                        "অতএব তারা যেন এবাদত করে এই ঘরের পালনকর্তার যিনি তাদেরকে ক্ষুধায় আহার দিয়েছেন \n" +
                        "এবং যুদ্ধভীতি থেকে তাদেরকে নিরাপদ করেছেন।";




                Intent myIntent=new Intent(SuraActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });




        //=====




    }
}