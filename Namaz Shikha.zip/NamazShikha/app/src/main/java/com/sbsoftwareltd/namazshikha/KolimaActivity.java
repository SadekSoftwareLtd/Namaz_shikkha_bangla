package com.sbsoftwareltd.namazshikha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class KolimaActivity extends AppCompatActivity {

    Button oz,oz1,oz2,oz3,oz4;
    private AdView mAdView5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kolima);


        //==========

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        AdView adView = new AdView(this);

        adView.setAdSize(AdSize.BANNER);

        adView.setAdUnitId("ca-app-pub-6331473249617603/7694863398");

        mAdView5=findViewById(R.id.mAdView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView5.loadAd(adRequest);

        //========



        oz=findViewById(R.id.oz);
        oz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="কালেমা তাইয়্যেবা";

                BebronActivity.LOVE2="لاَ اِلَهَ اِلاَّ اللهُ مُحَمَّدُ رَّسُوْ لُ الله\n" +
                        "\n" +
                        "উচ্চারণ : লা-ইলাহা ইল্লাল্লাহু মুহাম্মাদুর রাসূলুল্লাহ ।\n" +
                        "\n" +
                        "অনুবাদ ঃ আল্লাহ ভিন্ন ইবাদত বন্দেগীর উপযুক্ত আর কেহই নাই । হযরত মুহাম্মদ ছাল্লাল্লাহু আলাইহি ওয়াছাল্লাম তাঁহার প্রেরিত রসূল ।";


                Intent myIntent=new Intent(KolimaActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });

        oz1=findViewById(R.id.oz1);
        oz1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="কালেমা শাহাদত";

                BebronActivity.LOVE2="اَشْهَدُ اَنْ لاَّ اِلَهَ اِلاَّ اللهُ وَحْدَهُ لاَشَرِيْكَ لَه' وَاَشْهَدُ اَنَّ مُحَمَّدًا عَبْدُه' وَرَسُوْلُه'\n" +
                        "\n" +
                        "উচ্চারন ঃ আশহাদু আল লা-ইলাহা ইল্লাল্লাহু ওহদাহু লা-শারীকালাহু ওয়াশহাদু আন্না মুহাম্মাদান আবদুহু ওয়া রাছুলুহু ।\n" +
                        "\n" +
                        "অনুবাদ ঃ আমি সাক্ষ্য দিতেছি যে , অল্লাহ ভিন্ন আর কেহই ইবাদতের উপযুক্ত নাই তিনি এক তাঁহার কোন অংশীদার নাই । আমি আরও সাক্ষ্য দিতেছি যে, হযরত মুহাম্মদ (সাল্লাহু আলাইহে ওয়া সাল্লাম) আল্লাহর শ্রেষ্ঠ বান্দা এবং তাঁহার প্রেরিত নবী ।";


                Intent myIntent=new Intent(KolimaActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });




        oz2=findViewById(R.id.oz2);
        oz2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="কালেমা তাওহীদ";

                BebronActivity.LOVE2="لاَ اِلَهَ اِلاَّ اَنْتَ وَاحِدَ لاَّثَانِىَ لَكَ مُحَمَّدُرَّ سُوْلُ اللهِ اِمَامُ الْمُتَّقِيْنَ رَسُوْ لُرَبِّ الْعَلَمِيْنَ\n" +
                        "\n" +
                        "উচ্চারণ ঃ লা-ইলাহা ইল্লা আনতা ওয়াহেদাল্লা ছানীয়ালাকা মুহাম্মাদুর রাসূলুল্লা ইমামুল মোত্তাকীনা রাছুলুরাবি্বল আলামীন ।\n" +
                        "\n" +
                        "অনুবাদ ঃ আল্লাহ ভিন্ন কেহ এবাদতের যোগ্য নাই । তিনি এক তাঁহার অংশীদার নাই মুহাম্মদ রাসুলুল্লাহ (সাল্লাহু আলাইহে ওয়া সাল্লাম) সোত্তাকীনদের (ধর্মভীরুগণের) ইমাম এবং বিশ্বপালকের প্রেরিত ।";


                Intent myIntent=new Intent(KolimaActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });




        oz3=findViewById(R.id.oz3);
        oz3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="কালেমা তামজীদ";

                BebronActivity.LOVE2="لاَ اِلَهَ اِلاَّ اَنْتَ نُوْرَ يَّهْدِىَ اللهُ لِنُوْرِهِ مَنْ يَّشَاءُ مُحَمَّدُ رَّسَوْ لُ اللهِ اِمَامُ الْمُرْسَلِيْنَ خَا تَمُ النَّبِيِّنَ\n" +
                        "\n" +
                        "উচ্চারন ঃ লা-ইলাহা ইল্লা আনতা নুরাইইয়াহ দিয়াল্লাহু লিনুরিহী মাইয়্যাশাউ মুহাম্মাদুর রাসূলুল্লাহি ইমামূল মুরছালীনা খাতামুন-নাবিয়্যীন ।\n" +
                        "\n" +
                        "অনুবাদ ঃ হে খোদা! তুমি ব্যতীত কেহই উপাস্য নাই, তুমি জ্যোতিময় । তুমি যাহাকে ইচ্ছা আপন জ্যোতিঃ প্রদর্শন কর । মুহাম্মদ (সাল্লাহু আলাইহে ওয়া সাল্লাম) প্রেরিত পয়গম্বরগণের ইমাম এবং শেষ নবী।";


                Intent myIntent=new Intent(KolimaActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });


        oz4=findViewById(R.id.oz4);
        oz4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BebronActivity.LOVE="কালেমা রদ্দেকুফর";

                BebronActivity.LOVE2="اَللَّهُمَّ اِنِّىْ اَعُوْذُبِكَ مِنْ اَنْ اُشْرِكَ بِكَ شَيْئً وَاَنَا اعَلَمُ بِهِ وَاَسْتَغْفِرُكَ لِمَا اعَلَمُ بِهِ وَمَا لاَاعَلَمُ بِهِ تُبْتُ عَنْهُ وَتَبَرَّأتُ مِنَ الْكُفْرِ وَالشِّرْكِ وَالْمَعَاصِىْ كُلِّهَا وَاَسْلَمْتُ وَاَمَنْتُ وَاَقُوْلُ اَنْ لاَّاِلَهَ اِلاَّاللهُ مُحَمَّدُ رَّسَوْلُ اللهِ –\n" +
                        "\n" +
                        "উচ্চারণ ঃ আল্লাহুম্মা ইন্নী আউযুবিকা মিন আন উশরিকা বিকা শাইআও ওয়া আনা আলামু বিহি ওয়া আসতাগ ফিরুকা লিমা আলামু বিহি ওয়ামা লা আলামু বিহি তুবতু আনহু ওয়া তাবাররাতু মিনাল কুফরি ওয়াশ্শির্কি ওয়াল মা আছি কুল্লিহা ওয়া আসলামতু ওয়া আমানতু ওয়া আক্বলু আল্লা ইলাহা ইল্লাল্লাহু মুহাম্মাদু রাসূলুল্লাহ ।\n" +
                        "\n" +
                        "অনুবাদ ঃ হে আল্লাহ! আমি তোমার নিকট আশা করছি, যেন কাহাকেও তোমান সহিত অংশীদার না করি । আমার জানা-অজানা গুনাহ হতে ক্ষমা চাহিতেছি এবং ইহা হতে তওবা করিতেছি । কুফর, শিরক এবং অন্যান্য সমস্ত গুনাহ হতে বিদুরীত হইতেছি এবং প্রতিজ্ঞা করিতেছি আল্লাহ ব্যতীত অন্য কোন মাবুদ নাই, মুহাম্মদ মুস্তফা (সাল্লাহু আলাইহে ওয়া সাল্লাম) তাঁহার রাসুল ।\n";


                Intent myIntent=new Intent(KolimaActivity.this, BebronActivity.class);
                startActivity(myIntent);





            }
        });











    }
}