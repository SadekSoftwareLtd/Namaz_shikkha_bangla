package com.sbsoftwareltd.namazshikha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class WelcomeActivity extends AppCompatActivity {

    LinearLayout welcome,sh,pr,ab,ra,mr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        welcome=findViewById(R.id.welcome);

        welcome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent myIntent=new Intent(WelcomeActivity.this, MainActivity.class);
                startActivity(myIntent);




            }
        });



      ab=findViewById(R.id.ab);

        ab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent myIntent=new Intent(WelcomeActivity.this, AboutActivity.class);
                startActivity(myIntent);




            }
        });
 pr=findViewById(R.id.pr);

        pr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://appnamazshikha.blogspot.com/2024/02/privacy-policy.html"));
                startActivity(browserIntent);






            }
        });


       sh=findViewById(R.id.sh);

        sh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                shareContent();




            }
        });

        mr=findViewById(R.id.mr);

        mr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/dev?id=5105236906261444271")));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                }






            }
        });

        ra=findViewById(R.id.ra);

        ra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rateApp();;






            }
        });






    }

    //==================
    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

    //================================================================================================


    private void shareContent() {
        // Content to be shared
        String shareText = "Check out this awesome app! " +
                "\n" +
                "https://play.google.com/store/apps/details?id=com.sbsoftwareltd.sbsoftwareltd/namazshikha";

        // Create a new intent with ACTION_SEND
        Intent shareIntent = new Intent(Intent.ACTION_SEND);

        // Set the type of content to be shared (plain text in this case)
        shareIntent.setType("text/plain");

        // Put the content to be shared in the intent
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);

        // Start the activity with the share intent
        startActivity(Intent.createChooser(shareIntent, "Share via"));
    }

    //=============================================================================


    //===============

    public void rateApp()
    {
        try
        {
            Intent rateIntent = rateIntentForUrl("market://details");
            startActivity(rateIntent);
        }
        catch (ActivityNotFoundException e)
        {
            Intent rateIntent = rateIntentForUrl("https://play.google.com/store/apps/details?id=com.sbsoftwareltd.riccalculatorbd");
            startActivity(rateIntent);
        }
    }

    private Intent rateIntentForUrl(String url)
    {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format("%s?id=%s", url, getPackageName())));
        int flags = Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_MULTIPLE_TASK;
        if (Build.VERSION.SDK_INT >= 21)
        {
            flags |= Intent.FLAG_ACTIVITY_NEW_DOCUMENT;
        }
        else
        {
            //noinspection deprecation
            flags |= Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET;
        }
        intent.addFlags(flags);
        return intent;
    }



    //=========






}